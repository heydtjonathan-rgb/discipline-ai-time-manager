//
//  DisciplineApp.swift
//  Discipline
//
//  Created by Joni on 08.11.26.
//

import SwiftUI
import UIKit

enum DisciplineTheme: String, CaseIterable, Identifiable {
    case mint
    case ocean
    case violet
    case amber

    var id: String { rawValue }

    func name(language: DisciplineLanguage) -> String {
        switch self {
        case .mint: "Mint"
        case .ocean: language.text("Ozean", "Ocean")
        case .violet: language.text("Violett", "Violet")
        case .amber: "Amber"
        }
    }

    var alternateIconName: String? {
        switch self {
        case .mint: nil
        case .ocean: "AppIconOcean"
        case .violet: "AppIconViolet"
        case .amber: "AppIconAmber"
        }
    }

    var accent: Color {
        switch self {
        case .mint: Color(red: 0.18, green: 0.93, blue: 0.78)
        case .ocean: Color(red: 0.27, green: 0.62, blue: 1.00)
        case .violet: Color(red: 0.72, green: 0.45, blue: 1.00)
        case .amber: Color(red: 1.00, green: 0.65, blue: 0.24)
        }
    }
}

enum DisciplineLanguage: String, CaseIterable, Identifiable {
    case german = "de"
    case english = "en"

    static let storageKey = "discipline.language"

    static var current: DisciplineLanguage {
        DisciplineLanguage(rawValue: UserDefaults.standard.string(forKey: storageKey) ?? "de") ?? .german
    }

    var id: String { rawValue }

    var name: String {
        switch self {
        case .german: "Deutsch"
        case .english: "English"
        }
    }

    func text(_ german: String, _ english: String) -> String {
        self == .english ? english : german
    }
}

private struct DisciplineThemeKey: EnvironmentKey {
    static let defaultValue = DisciplineTheme.mint
}

private struct DisciplineLanguageKey: EnvironmentKey {
    static let defaultValue = DisciplineLanguage.german
}

extension EnvironmentValues {
    var disciplineTheme: DisciplineTheme {
        get { self[DisciplineThemeKey.self] }
        set { self[DisciplineThemeKey.self] = newValue }
    }

    var disciplineLanguage: DisciplineLanguage {
        get { self[DisciplineLanguageKey.self] }
        set { self[DisciplineLanguageKey.self] = newValue }
    }
}

@main
struct DisciplineApp: App {
    @AppStorage("discipline.theme") private var themeName = DisciplineTheme.mint.rawValue
    @AppStorage(DisciplineLanguage.storageKey) private var languageCode = DisciplineLanguage.german.rawValue

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.disciplineTheme, selectedTheme)
                .environment(\.disciplineLanguage, selectedLanguage)
                .environment(\.locale, Locale(identifier: selectedLanguage.rawValue))
                .tint(selectedTheme.accent)
                .preferredColorScheme(.dark)
        }
    }

    private var selectedTheme: DisciplineTheme {
        DisciplineTheme(rawValue: themeName) ?? .mint
    }

    private var selectedLanguage: DisciplineLanguage {
        DisciplineLanguage(rawValue: languageCode) ?? .german
    }
}
