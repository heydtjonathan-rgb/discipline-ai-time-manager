import Combine
import Security
import SwiftUI
import UIKit

struct DisciplineTask: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String
    var details: String
    var duration: Int
    var completed: Bool = false
    var scheduledTime: String = ""
    var repeatIntervalDays: Int? = nil
    var completedAt: Date? = nil
}

enum PhotoCodec {
    static func jpegData(from image: UIImage, maximumDimension: CGFloat = 1000) -> Data? {
        let sourceSize = image.size
        guard sourceSize.width > 0, sourceSize.height > 0 else {
            return nil
        }

        let scale = min(maximumDimension / max(sourceSize.width, sourceSize.height), 1)
        let size = CGSize(width: sourceSize.width * scale, height: sourceSize.height * scale)
        let renderer = UIGraphicsImageRenderer(size: size)
        let normalizedImage = renderer.image { _ in
            image.draw(in: CGRect(origin: .zero, size: size))
        }
        return normalizedImage.jpegData(compressionQuality: 0.75)
    }
}

enum TaskStorage {
    private static let key = "discipline.tasks"

    static func load() throws -> [DisciplineTask] {
        guard let data = UserDefaults.standard.data(forKey: key) else {
            let language = DisciplineLanguage.current
            return [
                DisciplineTask(
                    title: language.text("Zähne putzen", "Brush your teeth"),
                    details: language.text("Putze deine Zähne gründlich.", "Brush your teeth thoroughly."),
                    duration: 120,
                    scheduledTime: "07:00"
                ),
                DisciplineTask(
                    title: language.text("Bett machen", "Make your bed"),
                    details: language.text("Mache dein Bett ordentlich.", "Make your bed neatly."),
                    duration: 180,
                    scheduledTime: "07:15"
                ),
                DisciplineTask(
                    title: language.text("Zimmer aufräumen", "Tidy your room"),
                    details: language.text("Räume dein Zimmer auf.", "Tidy your room."),
                    duration: 600,
                    scheduledTime: "18:00"
                )
            ]
        }

        return try JSONDecoder().decode([DisciplineTask].self, from: data)
    }

    static func save(_ tasks: [DisciplineTask]) throws {
        let data = try JSONEncoder().encode(tasks)
        UserDefaults.standard.set(data, forKey: key)
    }
}

struct AICompletionResponse: Decodable {
    let completed: Bool
    let confidence: Double
    let explanation: String

    private enum CodingKeys: String, CodingKey {
        case completed
        case confidence
        case explanation
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        completed = try container.decode(Bool.self, forKey: .completed)
        confidence = try container.decodeIfPresent(Double.self, forKey: .confidence) ?? 0
        explanation = try container.decodeIfPresent(String.self, forKey: .explanation)
            ?? DisciplineLanguage.current.text(
                "Die KI hat keine Begründung geliefert.",
                "The AI did not provide an explanation."
            )
    }
}

private struct OpenRouterRequest: Encodable {
    let model = "openrouter/free"
    let input: [InputMessage]
    let store = false

    enum CodingKeys: String, CodingKey {
        case model, input, store
    }

    struct InputMessage: Encodable {
        let role: String
        let content: [InputPart]
    }

    struct InputPart: Encodable {
        let type: String
        let text: String?
        let imageURL: String?

        enum CodingKeys: String, CodingKey {
            case type, text
            case imageURL = "image_url"
        }
    }
}

private struct OpenRouterResponse: Decodable {
    let output: [OutputItem]?

    struct OutputItem: Decodable {
        let type: String?
        let content: [OutputContent]?
    }

    struct OutputContent: Decodable {
        let type: String?
        let text: String?
    }
}

private struct OpenRouterErrorResponse: Decodable {
    let error: APIError

    struct APIError: Decodable {
        let message: String
    }
}

enum AICompletionError: LocalizedError {
    case missingAPIKey
    case missingImage
    case invalidResponse(String)
    case serverStatus(Int, String?)
    case lowConfidence(Double)

    var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            DisciplineLanguage.current.text(
                "Bitte zuerst einen OpenRouter-API-Key in der Aufgabenverwaltung speichern.",
                "Add an OpenRouter API key in task management first."
            )
        case .missingImage:
            DisciplineLanguage.current.text(
                "Das Kamerafoto konnte nicht verarbeitet werden.",
                "The camera photo could not be processed."
            )
        case .invalidResponse(let detail):
            DisciplineLanguage.current.text(
                "Der KI-Server hat eine ungültige Antwort geliefert. \(detail)",
                "The AI server returned an invalid response. \(detail)"
            )
        case .serverStatus(let code, let detail):
            DisciplineLanguage.current.text(
                "OpenRouter hat HTTP \(code) zurückgegeben.\(detail.map { " \($0)" } ?? "")",
                "OpenRouter returned HTTP \(code).\(detail.map { " \($0)" } ?? "")"
            )
        case .lowConfidence(let confidence):
            DisciplineLanguage.current.text(
                "Die KI ist nicht sicher genug (Sicherheit: \(Int(confidence * 100)) %). Bitte ein neues Foto aufnehmen.",
                "The AI is not confident enough (confidence: \(Int(confidence * 100))%). Please take another photo."
            )
        }
    }
}

enum AICompletionService {
    static let confidenceThreshold = 0.50
    private static let endpoint = URL(string: "https://openrouter.ai/api/v1/responses")!
    private static let tokenService = "de.discipline.ai"
    private static let tokenAccount = "openrouter-api-key"

    static var hasToken: Bool {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: tokenService,
            kSecAttrAccount as String: tokenAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        return SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess
    }

    static func maskedTokenSummaries() throws -> [String] {
        try loadTokens().enumerated().map { index, token in
            let suffix = token.count > 4 ? " · endet auf \(token.suffix(4))" : ""
            return DisciplineLanguage.current.text(
                "Schlüssel \(index + 1)\(suffix)",
                "Key \(index + 1)\(suffix)"
            )
        }
    }

    static func addAPIKey(_ apiKey: String) throws {
        let value = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else {
            throw AICompletionError.missingAPIKey
        }

        var tokens = try loadTokens()
        guard !tokens.contains(value) else {
            throw AICompletionError.invalidResponse(
                DisciplineLanguage.current.text(
                    "Dieser API-Key ist bereits gespeichert.",
                    "This API key is already saved."
                )
            )
        }
        tokens.append(value)
        try saveTokens(tokens)
    }

    static func removeAPIKey(at index: Int) throws {
        var tokens = try loadTokens()
        guard tokens.indices.contains(index) else {
            throw AICompletionError.invalidResponse(
                DisciplineLanguage.current.text(
                    "Der ausgewählte API-Key ist nicht mehr verfügbar.",
                    "The selected API key is no longer available."
                )
            )
        }
        tokens.remove(at: index)
        if tokens.isEmpty {
            try removeToken()
        } else {
            try saveTokens(tokens)
        }
    }

    static func removeToken() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: tokenService,
            kSecAttrAccount as String: tokenAccount
        ]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
        }
    }

    static func assess(task: DisciplineTask, image: Data) async throws -> AICompletionResponse {
        guard !image.isEmpty else {
            throw AICompletionError.missingImage
        }
        guard let token = try nextToken(), !token.isEmpty else {
            throw AICompletionError.missingAPIKey
        }

        let taskDescription = task.details.isEmpty
            ? DisciplineLanguage.current.text("Keine zusätzliche Beschreibung.", "No additional description.")
            : task.details
        let english = DisciplineLanguage.current == .english
        let prompt = """
        \(english
            ? "Check only from the attached photo whether this task is visibly complete."
            : "Prüfe ausschließlich anhand des angehängten Fotos, ob diese Aufgabe sichtbar erledigt ist.")
        \(english ? "Task:" : "Aufgabenname:") \(task.title)
        \(english ? "Description:" : "Beschreibung:") \(taskDescription)
        \(english
            ? "Be cautious: if the result is not clearly visible, answer completed=false."
            : "Sei vorsichtig: Wenn das Ergebnis nicht klar erkennbar ist, antworte completed=false.")
        \(english
            ? "Reply only with a JSON object, without Markdown or other text:"
            : "Antworte ausschließlich mit einem JSON-Objekt, ohne Markdown oder weiteren Text:")
        {"completed": true or false, "confidence": number between 0 and 1, "explanation": "\(english ? "brief explanation in English" : "kurze Begründung auf Deutsch")"}
        \(english
            ? "confidence is your estimated certainty. Do not invent details that are not visible in the image."
            : "confidence ist deine geschätzte Sicherheit. Erfinde keine im Bild nicht erkennbaren Details.")
        """

        var request = URLRequest(url: endpoint, timeoutInterval: 60)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        request.setValue("Discipline", forHTTPHeaderField: "X-OpenRouter-Title")
        request.httpBody = try JSONEncoder().encode(
            OpenRouterRequest(input: [
                .init(role: "user", content: [
                    .init(type: "input_text", text: prompt, imageURL: nil),
                    .init(
                        type: "input_image",
                        text: nil,
                        imageURL: "data:image/jpeg;base64,\(image.base64EncodedString())"
                    )
                ])
            ])
        )

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw AICompletionError.invalidResponse(
                DisciplineLanguage.current.text("Es kam keine HTTP-Antwort zurück.", "No HTTP response was received.")
            )
        }
        guard (200..<300).contains(httpResponse.statusCode) else {
            let detail = try? JSONDecoder().decode(OpenRouterErrorResponse.self, from: data).error.message
            throw AICompletionError.serverStatus(httpResponse.statusCode, detail)
        }

        let completion: OpenRouterResponse
        do {
            completion = try JSONDecoder().decode(OpenRouterResponse.self, from: data)
        } catch {
            throw AICompletionError.invalidResponse(
                "OpenRouter-Antwort konnte nicht gelesen werden: \(decodingDescription(for: error))"
            )
        }

        let messageContent = completion.output?
            .filter { $0.type == "message" }
            .flatMap { $0.content ?? [] }
            .compactMap(\.text)
            .joined()
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard let content = messageContent,
              !content.isEmpty,
              let jsonStart = content.firstIndex(of: "{"),
              let jsonEnd = content.lastIndex(of: "}"),
              jsonStart <= jsonEnd else {
            throw AICompletionError.invalidResponse(
                DisciplineLanguage.current.text(
                    "OpenRouter lieferte keinen lesbaren Antworttext.",
                    "OpenRouter returned no readable response text."
                )
            )
        }
        let json = String(content[jsonStart...jsonEnd])
        let assessment: AICompletionResponse
        do {
            assessment = try JSONDecoder().decode(AICompletionResponse.self, from: Data(json.utf8))
        } catch {
            throw AICompletionError.invalidResponse(
                "KI-Antwort war kein gültiges Prüfungs-JSON: \(decodingDescription(for: error))"
            )
        }
        guard assessment.confidence.isFinite,
              (0...1).contains(assessment.confidence) else {
            throw AICompletionError.invalidResponse(
                DisciplineLanguage.current.text(
                    "Die KI lieferte einen ungültigen Sicherheitswert.",
                    "The AI returned an invalid confidence value."
                )
            )
        }
        guard !assessment.explanation.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw AICompletionError.invalidResponse(
                DisciplineLanguage.current.text("Die KI lieferte keine Begründung.", "The AI returned no explanation.")
            )
        }
        return assessment
    }

    private static func decodingDescription(for error: Error) -> String {
        guard let decodingError = error as? DecodingError else {
            return error.localizedDescription
        }
        switch decodingError {
        case .keyNotFound(let key, _):
            return DisciplineLanguage.current.text(
                "Pflichtfeld „\(key.stringValue)“ fehlt.",
                "Required field \"\(key.stringValue)\" is missing."
            )
        case .typeMismatch(_, let context):
            let path = context.codingPath.map(\.stringValue).joined(separator: ".")
            return DisciplineLanguage.current.text(
                "Unerwarteter Datentyp bei \(path).",
                "Unexpected data type at \(path)."
            )
        case .valueNotFound(_, let context):
            let path = context.codingPath.map(\.stringValue).joined(separator: ".")
            return DisciplineLanguage.current.text(
                "Wert fehlt bei \(path).",
                "Value is missing at \(path)."
            )
        case .dataCorrupted(let context):
            return DisciplineLanguage.current.text(
                "Antwortdaten sind ungültig: \(context.debugDescription)",
                "Response data is invalid: \(context.debugDescription)"
            )
        @unknown default:
            return error.localizedDescription
        }
    }

    private static func loadTokens() throws -> [String] {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: tokenService,
            kSecAttrAccount as String: tokenAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound {
            return []
        }
        guard status == errSecSuccess,
              let data = result as? Data,
              let storedValue = String(data: data, encoding: .utf8) else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
        }

        if let tokens = try? JSONDecoder().decode([String].self, from: data) {
            return tokens.filter { !$0.isEmpty }
        }
        return storedValue.isEmpty ? [] : [storedValue]
    }

    private static func nextToken() throws -> String? {
        var tokens = try loadTokens()
        guard !tokens.isEmpty else { return nil }
        let token = tokens.removeFirst()
        tokens.append(token)
        try saveTokens(tokens)
        return token
    }

    private static func saveTokens(_ tokens: [String]) throws {
        let data = try JSONEncoder().encode(tokens)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: tokenService,
            kSecAttrAccount as String: tokenAccount
        ]
        let update: [String: Any] = [
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        let status = SecItemUpdate(query as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var addQuery = query
            addQuery[kSecValueData as String] = data
            addQuery[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            let addStatus = SecItemAdd(addQuery as CFDictionary, nil)
            guard addStatus == errSecSuccess else {
                throw NSError(domain: NSOSStatusErrorDomain, code: Int(addStatus))
            }
        } else if status != errSecSuccess {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
        }
    }
}

enum PinVerification {
    case valid
    case invalid
    case error(OSStatus)
}

enum PinPresence {
    case present
    case absent
    case error(OSStatus)
}

enum PinManager {
    private static let service = "de.discipline.security"
    private static let account = "admin-pin"

    private static var identityQuery: [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
    }

    static func presence() -> PinPresence {
        var result: CFTypeRef?
        var query = identityQuery
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne

        switch SecItemCopyMatching(query as CFDictionary, &result) {
        case errSecSuccess:
            return .present
        case errSecItemNotFound:
            return .absent
        case let status:
            return .error(status)
        }
    }

    static func save(_ pin: String) -> OSStatus {
        let value = Data(pin.utf8)

        let status = SecItemUpdate(
            identityQuery as CFDictionary,
            [
                kSecValueData as String: value,
                kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            ] as CFDictionary
        )

        guard status == errSecItemNotFound else {
            return status
        }

        var query = identityQuery
        query[kSecValueData as String] = value
        query[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        return SecItemAdd(query as CFDictionary, nil)
    }

    static func verify(_ pin: String) -> PinVerification {
        var query = identityQuery
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne

        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess else {
            return .error(status)
        }
        guard let data = result as? Data,
              let storedPIN = String(data: data, encoding: .utf8) else {
            return .error(errSecDecode)
        }

        return storedPIN == pin ? .valid : .invalid
    }

    static func errorMessage(for status: OSStatus) -> String {
        SecCopyErrorMessageString(status, nil) as String?
            ?? DisciplineLanguage.current.text(
                "Schlüsselbundfehler (\(status)).",
                "Keychain error (\(status))."
            )
    }
}

private enum PresentedSheet: Identifiable {
    case pin(isSetup: Bool)
    case management
    case appearance

    var id: String {
        switch self {
        case .pin: "pin"
        case .management: "management"
        case .appearance: "appearance"
        }
    }
}

struct ContentView: View {
    @Environment(\.disciplineTheme) private var theme
    @Environment(\.disciplineLanguage) private var language
    @Environment(\.scenePhase) private var scenePhase
    @State private var tasks: [DisciplineTask]
    @State private var activeTask: DisciplineTask?
    @State private var presentedSheet: PresentedSheet?
    @State private var notice = ""

    init() {
        do {
            _tasks = State(initialValue: try TaskStorage.load())
        } catch {
            _tasks = State(initialValue: [])
            _notice = State(initialValue: DisciplineLanguage.current.text(
                "Aufgaben konnten nicht geladen werden: \(error.localizedDescription)",
                "Could not load tasks: \(error.localizedDescription)"
            ))
        }
    }

    private var completedCount: Int {
        tasks.filter(\.completed).count
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 25) {
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text("DISCIPLINE")
                                .font(.caption.bold())
                                .tracking(5)
                                .foregroundStyle(theme.accent)
                            Spacer()
                            Button {
                                presentedSheet = .appearance
                            } label: {
                                Image(systemName: "paintpalette.fill")
                                    .font(.title3)
                                    .foregroundStyle(theme.accent)
                            }
                            .accessibilityLabel(language.text("Farbschema und App-Symbol ändern", "Change color scheme and app icon"))
                        }

                        Text(language.text("Dein Tag.\nDeine Regeln.", "Your day.\nYour rules."))
                            .font(.system(size: 38, weight: .bold))

                        Text(language.text(
                            "Erledige deine Aufgaben und verdiene dir deine Freizeit.",
                            "Complete your tasks and earn your free time."
                        ))
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text(language.text("Tagesfortschritt", "Daily progress"))
                                .font(.headline)
                            Spacer()
                            Text("\(completedCount)/\(tasks.count)")
                                .foregroundStyle(theme.accent)
                        }

                        ProgressView(
                            value: Double(completedCount),
                            total: Double(max(tasks.count, 1))
                        )
                        .tint(theme.accent)
                        .accessibilityLabel(language.text("Tagesfortschritt", "Daily progress"))
                    }
                    .padding()
                    .background(.white.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 18))

                    HStack {
                        Text(language.text("DEINE AUFGABEN", "YOUR TASKS"))
                            .font(.caption.bold())
                            .tracking(2)
                        Spacer()
                        Button {
                            openManagement()
                        } label: {
                            Image(systemName: "plus.circle.fill")
                                .font(.title2)
                                .foregroundStyle(theme.accent)
                        }
                        .accessibilityLabel(language.text("Aufgaben verwalten", "Manage tasks"))
                    }

                    if tasks.isEmpty {
                        ContentUnavailableView(
                            language.text("Noch keine Aufgaben", "No tasks yet"),
                            systemImage: "checklist",
                            description: Text(language.text(
                                "Füge über das Plus-Symbol deine erste Aufgabe hinzu.",
                                "Add your first task using the plus button."
                            ))
                        )
                    } else {
                        ForEach(tasks) { task in
                            Button {
                                startTask(task)
                            } label: {
                                HStack(spacing: 14) {
                                    Image(systemName: task.completed ? "checkmark.circle.fill" : "circle")
                                        .font(.title2)
                                        .foregroundStyle(theme.accent)

                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(task.title)
                                            .font(.headline)
                                            .foregroundStyle(.primary)
                                        Text(taskSubtitle(task, language: language))
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                            .lineLimit(2)
                                    }

                                    Spacer()

                                    Image(systemName: "arrow.right")
                                        .foregroundStyle(.secondary)
                                }
                                .padding()
                                .background(.white.opacity(0.06))
                                .clipShape(RoundedRectangle(cornerRadius: 17))
                            }
                            .buttonStyle(.plain)
                            .disabled(task.completed)
                        }
                    }

                }
                .padding()
            }
            .background(Color.black)
            .toolbar(.hidden, for: .navigationBar)
            .onChange(of: tasks) { _, updatedTasks in
                do {
                    try TaskStorage.save(updatedTasks)
                } catch {
                    notice = language.text(
                        "Aufgaben konnten nicht gespeichert werden: \(error.localizedDescription)",
                        "Could not save tasks: \(error.localizedDescription)"
                    )
                }
            }
            .onAppear(perform: refreshRecurringTasks)
            .onChange(of: scenePhase) { _, phase in
                if phase == .active {
                    refreshRecurringTasks()
                }
            }
            .onReceive(Timer.publish(every: 30, on: .main, in: .common).autoconnect()) { _ in
                refreshRecurringTasks()
            }
            .onOpenURL(perform: handleShortcut)
            .fullScreenCover(item: $activeTask) { task in
                ExamModeView(task: task) {
                    completeTask(task)
                }
            }
            .sheet(item: $presentedSheet) { sheet in
                switch sheet {
                case .pin(let isSetup):
                    PinView(isSetup: isSetup) {
                        presentedSheet = .management
                    }
                case .management:
                    TaskManagementView(tasks: $tasks)
                case .appearance:
                    ThemePickerView()
                }
            }
            .alert("Discipline", isPresented: Binding(
                get: { !notice.isEmpty },
                set: { if !$0 { notice = "" } }
            )) {
                Button(language.text("OK", "OK"), role: .cancel) {}
            } message: {
                Text(notice)
            }
        }
    }

    private func openManagement() {
        switch PinManager.presence() {
        case .present:
            presentedSheet = .pin(isSetup: false)
        case .absent:
            presentedSheet = .pin(isSetup: true)
        case .error(let status):
            notice = language.text(
                "PIN-Status konnte nicht gelesen werden: \(PinManager.errorMessage(for: status))",
                "Could not read PIN status: \(PinManager.errorMessage(for: status))"
            )
        }
    }

    private func completeTask(_ task: DisciplineTask) {
        guard let index = tasks.firstIndex(where: { $0.id == task.id }) else {
            activeTask = nil
            return
        }
        tasks[index].completed = true
        tasks[index].completedAt = Date()
        activeTask = nil
    }

    private func refreshRecurringTasks() {
        let now = Date()
        var changed = false

        for index in tasks.indices {
            guard tasks[index].completed,
                  let intervalDays = tasks[index].repeatIntervalDays,
                  intervalDays > 0,
                  let completedAt = tasks[index].completedAt,
                  let nextDueDate = Calendar.current.date(
                    byAdding: .day,
                    value: intervalDays,
                    to: completedAt
                  ),
                  nextDueDate <= now else {
                continue
            }

            tasks[index].completed = false
            tasks[index].completedAt = nil
            changed = true
        }

        if changed {
            do {
                try TaskStorage.save(tasks)
            } catch {
                notice = language.text(
                    "Fällige Aufgaben konnten nicht aktualisiert werden: \(error.localizedDescription)",
                    "Could not update recurring tasks: \(error.localizedDescription)"
                )
            }
        }
    }

    private func taskSubtitle(_ task: DisciplineTask, language: DisciplineLanguage) -> String {
        var parts: [String] = []
        if !task.scheduledTime.isEmpty {
            parts.append("\(task.scheduledTime) Uhr")
        }
        if !task.details.isEmpty {
            parts.append(task.details)
        }
        if let interval = task.repeatIntervalDays {
            parts.append(language.text(
                "Wiederholt alle \(interval) \(interval == 1 ? "Tag" : "Tage")",
                "Repeats every \(interval) \(interval == 1 ? "day" : "days")"
            ))
        }
        return parts.isEmpty ? language.text("Keine Beschreibung", "No description") : parts.joined(separator: " · ")
    }

    private func startTask(_ task: DisciplineTask) {
        activeTask = task
    }

    private func handleShortcut(_ url: URL) {
        guard url.scheme?.lowercased() == "discipline",
              url.host?.lowercased() == "start",
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              let taskID = components.queryItems?.first(where: { $0.name == "task" })?.value,
              let id = UUID(uuidString: taskID),
              let task = tasks.first(where: { $0.id == id }),
              !task.completed else {
            notice = language.text(
                "Der Aufgabenlink ist ungültig oder die Aufgabe ist nicht mehr verfügbar.",
                "This task link is invalid or the task is no longer available."
            )
            return
        }
        startTask(task)
    }
}

struct ThemePickerView: View {
    @AppStorage("discipline.theme") private var themeName = DisciplineTheme.mint.rawValue
    @Environment(\.disciplineLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @State private var isUpdatingIcon = false
    @State private var notice = ""

    private var selectedTheme: DisciplineTheme {
        DisciplineTheme(rawValue: themeName) ?? .mint
    }

    var body: some View {
        NavigationStack {
            List {
                Section(language.text("Sprache", "Language")) {
                    AppLanguagePicker()
                }

                Section {
                    ForEach(DisciplineTheme.allCases) { option in
                        Button {
                            select(option)
                        } label: {
                            HStack(spacing: 14) {
                                Circle()
                                    .fill(option.accent)
                                    .frame(width: 26, height: 26)
                                Text(option.name(language: language))
                                    .foregroundStyle(.primary)
                                Spacer()
                                if option == selectedTheme {
                                    Image(systemName: "checkmark")
                                        .foregroundStyle(option.accent)
                                }
                            }
                            .contentShape(Rectangle())
                        }
                        .disabled(isUpdatingIcon)
                    }
                } header: {
                    Text(language.text("Farbschema und App-Symbol", "Color scheme and app icon"))
                } footer: {
                    Text(language.text(
                        "Die Akzentfarbe der App und das Symbol auf dem Home-Bildschirm werden gemeinsam geändert.",
                        "The app's accent color and Home Screen icon change together."
                    ))
                }
            }
            .navigationTitle(language.text("Erscheinungsbild", "Appearance"))
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("Fertig", "Done")) { dismiss() }
                }
            }
            .overlay {
                if isUpdatingIcon {
                    ProgressView(language.text("App-Symbol wird geändert …", "Updating app icon…"))
                        .padding()
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
                }
            }
            .alert("Discipline", isPresented: Binding(
                get: { !notice.isEmpty },
                set: { if !$0 { notice = "" } }
            )) {
                Button(language.text("OK", "OK"), role: .cancel) {}
            } message: {
                Text(notice)
            }
        }
    }

    private func select(_ option: DisciplineTheme) {
        guard option != selectedTheme else { return }
        guard UIApplication.shared.supportsAlternateIcons else {
            notice = language.text(
                "Dieses Gerät unterstützt das Ändern des App-Symbols nicht.",
                "This device does not support changing the app icon."
            )
            return
        }

        isUpdatingIcon = true
        UIApplication.shared.setAlternateIconName(option.alternateIconName) { error in
            isUpdatingIcon = false
            if let error {
                notice = language.text(
                    "Das App-Symbol konnte nicht geändert werden: \(error.localizedDescription)",
                    "Could not change the app icon: \(error.localizedDescription)"
                )
                return
            }
            themeName = option.rawValue
        }
    }
}

private struct AppLanguagePicker: View {
    @AppStorage(DisciplineLanguage.storageKey) private var languageCode = DisciplineLanguage.german.rawValue
    @Environment(\.disciplineLanguage) private var language

    var body: some View {
        Picker(language.text("App-Sprache", "App language"), selection: $languageCode) {
            Text("Deutsch").tag(DisciplineLanguage.german.rawValue)
            Text("English").tag(DisciplineLanguage.english.rawValue)
        }
        .pickerStyle(.segmented)
    }
}

struct ExamModeView: View {
    let task: DisciplineTask
    let onComplete: () -> Void

    @Environment(\.disciplineTheme) private var theme
    @Environment(\.disciplineLanguage) private var language
    @Environment(\.scenePhase) private var scenePhase
    @State private var remaining: Int
    @State private var isGuidedAccessActive = false
    @State private var isRequestingGuidedAccess = false
    @State private var requestedGuidedAccessState: Bool?
    @State private var isCameraPresented = false
    @State private var isVerifyingPhoto = false
    @State private var notice = ""
    private let deadline: Date

    init(task: DisciplineTask, onComplete: @escaping () -> Void) {
        self.task = task
        self.onComplete = onComplete
        let duration = max(task.duration, 0)
        _remaining = State(initialValue: duration)
        deadline = Date().addingTimeInterval(TimeInterval(duration))
    }

    var body: some View {
        VStack(spacing: 28) {
            Image(systemName: "shield.lefthalf.filled")
                .font(.system(size: 55))
                .foregroundStyle(theme.accent)

            Text(
                isGuidedAccessActive
                    ? language.text("STRIKTER MODUS", "STRICT MODE")
                    : language.text("OFFENER MODUS", "OPEN MODE")
            )
                .font(.caption.bold())
                .tracking(4)
                .foregroundStyle(theme.accent)

            Text(task.title)
                .font(.largeTitle.bold())
                .multilineTextAlignment(.center)

            if !task.details.isEmpty {
                Text(task.details)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            Text(timeString)
                .font(.system(size: 58, weight: .bold, design: .rounded))
                .monospacedDigit()
                .accessibilityLabel(language.text(
                    "Verbleibende Zeit \(timeString)",
                    "Time remaining \(timeString)"
                ))

            ProgressView(
                value: Double(max(task.duration - remaining, 0)),
                total: Double(max(task.duration, 1))
            )
            .tint(theme.accent)

            Text(language.text(
                "Erledige deine Aufgabe. Bestätige den Abschluss, wenn du fertig bist.",
                "Complete your task. Confirm when you are done."
            ))
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)

            if isGuidedAccessActive {
                Label(language.text("iOS-Ein-App-Modus aktiv", "iOS single-app mode is active"), systemImage: "lock.fill")
                    .font(.caption)
                    .foregroundStyle(theme.accent)
            } else if isRequestingGuidedAccess {
                ProgressView(language.text("Sperrstatus wird geprüft …", "Checking lock status…"))
            } else {
                Label(language.text("Open Mode · keine iOS-Sperre aktiv", "Open Mode · no iOS lock active"), systemImage: "lock.open")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Button {
                isCameraPresented = true
            } label: {
                Label(language.text("Abschlussfoto aufnehmen", "Take completion photo"), systemImage: "camera.fill")
                    .frame(maxWidth: .infinity)
                    .padding()
            }
            .buttonStyle(.borderedProminent)
            .tint(theme.accent)
            .disabled(
                isVerifyingPhoto
                    || !AICompletionService.hasToken
                    || !UIImagePickerController.isSourceTypeAvailable(.camera)
            )

            if !AICompletionService.hasToken {
                Text(language.text(
                    "Richte zuerst in „Aufgaben verwalten“ deinen OpenRouter-Key ein.",
                    "Add an OpenRouter key in Manage Tasks first."
                ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if !UIImagePickerController.isSourceTypeAvailable(.camera) {
                Text(language.text(
                    "Für den Fotoabgleich wird die Kamera eines iPhones benötigt.",
                    "A camera is required for photo verification."
                ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            if isVerifyingPhoto {
                ProgressView(language.text("Foto wird von der KI geprüft …", "AI is checking the photo…"))
            }

            Text(language.text(
                "Das Foto wird an OpenRouter übertragen. Die KI-Einschätzung kann falsch sein.",
                "The photo is sent to OpenRouter. The AI assessment may be wrong."
            ))
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(28)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
        .interactiveDismissDisabled(isGuidedAccessActive || isRequestingGuidedAccess)
        .onAppear(perform: requestGuidedAccess)
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active,
                  !isGuidedAccessActive,
                  !isRequestingGuidedAccess else {
                return
            }
            requestGuidedAccess()
        }
        .onReceive(NotificationCenter.default.publisher(
            for: UIAccessibility.guidedAccessStatusDidChangeNotification
        )) { _ in
            if let requestedGuidedAccessState {
                isGuidedAccessActive = requestedGuidedAccessState
            } else {
                isGuidedAccessActive.toggle()
            }
        }
        .sheet(isPresented: $isCameraPresented) {
            CameraCaptureView(isPresented: $isCameraPresented) { image in
                verifyPhoto(image)
            }
            .ignoresSafeArea()
        }
        .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { _ in
            remaining = max(Int(ceil(deadline.timeIntervalSinceNow)), 0)
        }
        .alert("Discipline", isPresented: Binding(
            get: { !notice.isEmpty },
            set: { if !$0 { notice = "" } }
        )) {
            Button(language.text("OK", "OK"), role: .cancel) {}
        } message: {
            Text(notice)
        }
    }

    private var timeString: String {
        String(format: "%02d:%02d", remaining / 60, remaining % 60)
    }

    private func requestGuidedAccess() {
        isRequestingGuidedAccess = true
        requestedGuidedAccessState = true
        UIAccessibility.requestGuidedAccessSession(enabled: true) { succeeded in
            isGuidedAccessActive = succeeded
            isRequestingGuidedAccess = false
            requestedGuidedAccessState = nil
        }
    }

    private func verifyPhoto(_ image: UIImage) {
        guard let proofData = PhotoCodec.jpegData(from: image) else {
            notice = language.text(
                "Das Kamerafoto konnte nicht verarbeitet werden.",
                "The camera photo could not be processed."
            )
            return
        }

        isVerifyingPhoto = true
        Task {
            do {
                let result = try await AICompletionService.assess(task: task, image: proofData)
                isVerifyingPhoto = false
                let explanation = result.explanation
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                    .prefix(400)
                guard result.completed else {
                    notice = language.text(
                        "Die KI meint, die Aufgabe ist noch nicht erledigt (\(Int(result.confidence * 100)) % Sicherheit): \(explanation)",
                        "The AI thinks the task is not complete yet (\(Int(result.confidence * 100))% confidence): \(explanation)"
                    )
                    return
                }

                guard result.confidence >= AICompletionService.confidenceThreshold else {
                    notice = language.text(
                        "\(AICompletionError.lowConfidence(result.confidence).localizedDescription)\n\nEinschätzung: \(explanation)",
                        "\(AICompletionError.lowConfidence(result.confidence).localizedDescription)\n\nAssessment: \(explanation)"
                    )
                    return
                }

                releaseLockAndComplete()
            } catch {
                isVerifyingPhoto = false
                notice = language.text(
                    "KI-Prüfung fehlgeschlagen: \(error.localizedDescription)",
                    "AI check failed: \(error.localizedDescription)"
                )
            }
        }
    }

    private func releaseLockAndComplete() {
        guard isGuidedAccessActive else {
            onComplete()
            return
        }

        isRequestingGuidedAccess = true
        requestedGuidedAccessState = false
        UIAccessibility.requestGuidedAccessSession(enabled: false) { succeeded in
            isRequestingGuidedAccess = false
            requestedGuidedAccessState = nil
            guard succeeded else {
                notice = language.text(
                    "iOS konnte den Ein-App-Modus nicht beenden. Bitte versuche es erneut oder beende den Guided-Access-Modus mit dem auf dem iPhone festgelegten Code.",
                    "iOS could not end single-app mode. Try again or end Guided Access using your iPhone passcode."
                )
                return
            }
            isGuidedAccessActive = false
            onComplete()
        }
    }
}

struct PinView: View {
    let isSetup: Bool
    let onUnlock: () -> Void

    @Environment(\.disciplineTheme) private var theme
    @Environment(\.disciplineLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @State private var pin = ""
    @State private var confirmation = ""
    @State private var error = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 22) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 45))
                    .foregroundStyle(theme.accent)

                Text(isSetup
                     ? language.text("PIN festlegen", "Set PIN")
                     : language.text("Verwaltung entsperren", "Unlock task management"))
                    .font(.title.bold())

                SecureField(language.text("Sechsstelliger PIN", "Six-digit PIN"), text: $pin)
                    .keyboardType(.numberPad)
                    .textFieldStyle(.roundedBorder)
                    .onChange(of: pin) { _, value in
                        pin = String(value.filter(\.isNumber).prefix(6))
                    }

                if isSetup {
                    SecureField(language.text("PIN wiederholen", "Confirm PIN"), text: $confirmation)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .onChange(of: confirmation) { _, value in
                            confirmation = String(value.filter(\.isNumber).prefix(6))
                        }
                }

                if !error.isEmpty {
                    Text(error)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                }

                Button(
                    isSetup
                        ? language.text("PIN speichern", "Save PIN")
                        : language.text("Entsperren", "Unlock"),
                    action: unlock
                )
                    .buttonStyle(.borderedProminent)
                    .tint(theme.accent)
                    .disabled(pin.count != 6 || (isSetup && confirmation.count != 6))
            }
            .padding(28)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black)
            .navigationTitle(language.text("Sicherheit", "Security"))
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("Abbrechen", "Cancel")) {
                        dismiss()
                    }
                }
            }
        }
    }

    private func unlock() {
        guard pin.count == 6, pin.allSatisfy(\.isNumber) else {
            error = language.text("Bitte sechs Ziffern eingeben.", "Enter six digits.")
            return
        }

        if isSetup {
            guard pin == confirmation else {
                error = language.text("PINs stimmen nicht überein.", "PINs do not match.")
                return
            }
            let status = PinManager.save(pin)
            guard status == errSecSuccess else {
                error = PinManager.errorMessage(for: status)
                return
            }
        } else {
            switch PinManager.verify(pin) {
            case .valid:
                break
            case .invalid:
                error = language.text("Falscher PIN.", "Incorrect PIN.")
                pin = ""
                return
            case .error(let status):
                error = PinManager.errorMessage(for: status)
                return
            }
        }

        onUnlock()
    }
}

struct TaskManagementView: View {
    @Binding var tasks: [DisciplineTask]

    @Environment(\.disciplineLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @State private var editingTask: DisciplineTask?
    @State private var showingNewTask = false
    @State private var notice = ""
    @State private var aiToken = ""
    @State private var savedAPIKeys: [String] = []

    var body: some View {
        NavigationStack {
            List {
                ForEach(tasks) { task in
                    HStack {
                        Button {
                            editingTask = task
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(task.title)
                                    .foregroundStyle(.primary)
                                Text(taskManagementSubtitle(task, language: language))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .buttonStyle(.plain)

                        Spacer()

                        Button {
                            copyShortcut(for: task)
                        } label: {
                            Image(systemName: "link")
                        }
                        .buttonStyle(.borderless)
                        .accessibilityLabel(language.text(
                            "Kurzbefehlslink für \(task.title) kopieren",
                            "Copy shortcut link for \(task.title)"
                        ))
                    }
                }
                .onDelete { offsets in
                    tasks.remove(atOffsets: offsets)
                }

                Section(language.text("KI-Foto-Prüfung", "AI photo verification")) {
                    ForEach(savedAPIKeys.indices, id: \.self) { index in
                        let summary = savedAPIKeys[index]
                        HStack {
                            Text(summary)
                            Spacer()
                            Button(role: .destructive) {
                                removeAIKey(at: index)
                            } label: {
                                Image(systemName: "trash")
                            }
                            .accessibilityLabel(language.text("\(summary) entfernen", "Remove \(summary)"))
                        }
                    }

                    SecureField(language.text("OpenRouter-API-Key hinzufügen", "Add OpenRouter API key"), text: $aiToken)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    Link(
                        language.text("OpenRouter-Key kostenlos erstellen", "Get a free OpenRouter key"),
                        destination: URL(string: "https://openrouter.ai/settings/keys")!
                    )

                    Button(language.text("API-Key sicher hinzufügen", "Securely add API key"), action: saveAIKey)
                        .disabled(aiToken.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    Text(language.text(
                        "Bei jeder KI-Prüfung wird der nächste gespeicherte Key verwendet und die Reihenfolge weitergedreht. Foto und Aufgabenbeschreibung werden an OpenRouter übertragen. Die Keys bleiben im iOS-Schlüsselbund auf diesem Gerät.",
                        "Each AI check uses the next saved key and rotates the order. The photo and task description are sent to OpenRouter. Keys are stored in this device's iOS Keychain."
                    ))
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Button {
                    showingNewTask = true
                } label: {
                    Label(language.text("Neue Aufgabe", "New task"), systemImage: "plus")
                }
            }
            .navigationTitle(language.text("Aufgaben verwalten", "Manage tasks"))
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    EditButton()
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button(language.text("Fertig", "Done")) {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showingNewTask) {
                TaskEditorView { task in
                    tasks.append(task)
                }
            }
            .sheet(item: $editingTask) { task in
                TaskEditorView(task: task) { updated in
                    guard let index = tasks.firstIndex(where: { $0.id == updated.id }) else {
                        return
                    }
                    tasks[index] = updated
                }
            }
            .onAppear(perform: refreshAPIKeys)
            .alert("Discipline", isPresented: Binding(
                get: { !notice.isEmpty },
                set: { if !$0 { notice = "" } }
            )) {
                Button(language.text("OK", "OK"), role: .cancel) {}
            } message: {
                Text(notice)
            }
        }
    }

    private func copyShortcut(for task: DisciplineTask) {
        var components = URLComponents()
        components.scheme = "discipline"
        components.host = "start"
        components.queryItems = [URLQueryItem(name: "task", value: task.id.uuidString)]
        guard let url = components.url else {
            notice = language.text(
                "Der Kurzbefehlslink konnte nicht erstellt werden.",
                "Could not create the shortcut link."
            )
            return
        }
        UIPasteboard.general.url = url
        notice = language.text(
            "Kurzbefehlslink wurde kopiert. Füge ihn in der Aktion „URL öffnen“ in Kurzbefehle ein.",
            "Shortcut link copied. Paste it into the “Open URL” action in Shortcuts."
        )
    }

    private func taskManagementSubtitle(_ task: DisciplineTask, language: DisciplineLanguage) -> String {
        var details: [String] = [
            task.scheduledTime.isEmpty ? language.text("Keine Uhrzeit", "No time") : task.scheduledTime
        ]
        if let interval = task.repeatIntervalDays {
            details.append(language.text(
                "Alle \(interval) \(interval == 1 ? "Tag" : "Tage")",
                "Every \(interval) \(interval == 1 ? "day" : "days")"
            ))
        }
        return details.joined(separator: " · ")
    }

    private func saveAIKey() {
        do {
            try AICompletionService.addAPIKey(aiToken)
            aiToken = ""
            refreshAPIKeys()
            notice = language.text("OpenRouter-Key wurde sicher hinzugefügt.", "OpenRouter key added securely.")
        } catch {
            notice = language.text(
                "OpenRouter-Key konnte nicht hinzugefügt werden: \(error.localizedDescription)",
                "Could not add OpenRouter key: \(error.localizedDescription)"
            )
        }
    }

    private func removeAIKey(at index: Int) {
        do {
            try AICompletionService.removeAPIKey(at: index)
            refreshAPIKeys()
            notice = language.text("OpenRouter-Key entfernt.", "OpenRouter key removed.")
        } catch {
            notice = language.text(
                "OpenRouter-Key konnte nicht entfernt werden: \(error.localizedDescription)",
                "Could not remove OpenRouter key: \(error.localizedDescription)"
            )
        }
    }

    private func refreshAPIKeys() {
        do {
            savedAPIKeys = try AICompletionService.maskedTokenSummaries()
        } catch {
            notice = language.text(
                "Gespeicherte OpenRouter-Keys konnten nicht geladen werden: \(error.localizedDescription)",
                "Could not load saved OpenRouter keys: \(error.localizedDescription)"
            )
        }
    }
}

struct TaskEditorView: View {
    let existingTask: DisciplineTask?
    let onSave: (DisciplineTask) -> Void

    @Environment(\.disciplineLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @State private var title: String
    @State private var details: String
    @State private var minutes: Int
    @State private var scheduledTime: String
    @State private var repeats: Bool
    @State private var repeatIntervalDays: Int

    init(task: DisciplineTask? = nil, onSave: @escaping (DisciplineTask) -> Void) {
        existingTask = task
        self.onSave = onSave
        _title = State(initialValue: task?.title ?? "")
        _details = State(initialValue: task?.details ?? "")
        _minutes = State(initialValue: max(1, (task?.duration ?? 120) / 60))
        _scheduledTime = State(initialValue: task?.scheduledTime ?? "")
        _repeats = State(initialValue: task?.repeatIntervalDays != nil)
        _repeatIntervalDays = State(initialValue: min(max(task?.repeatIntervalDays ?? 1, 1), 365))
    }

    var body: some View {
        NavigationStack {
            Form {
                Section(language.text("Aufgabe", "Task")) {
                    TextField(language.text("Name", "Name"), text: $title)
                    TextField(language.text("Beschreibung", "Description"), text: $details, axis: .vertical)
                        .lineLimit(2...5)
                }

                Section(language.text("Zeit", "Time")) {
                    Stepper(
                        language.text("\(minutes) Minuten", "\(minutes) minutes"),
                        value: $minutes,
                        in: 1...180
                    )
                    TextField(
                        language.text("Uhrzeit (z. B. 07:00)", "Time (e.g. 07:00)"),
                        text: $scheduledTime
                    )
                        .keyboardType(.numbersAndPunctuation)
                }

                Section(language.text("Wiederholung", "Repeat")) {
                    Toggle(language.text("Aufgabe wiederholen", "Repeat task"), isOn: $repeats)
                    if repeats {
                        Stepper(
                            language.text(
                                "Alle \(repeatIntervalDays) \(repeatIntervalDays == 1 ? "Tag" : "Tage")",
                                "Every \(repeatIntervalDays) \(repeatIntervalDays == 1 ? "day" : "days")"
                            ),
                            value: $repeatIntervalDays,
                            in: 1...365
                        )
                        Text(language.text(
                            "Nach dem Erledigen wird die Aufgabe nach diesem Intervall automatisch wieder geöffnet.",
                            "After completion, the task automatically becomes available again after this interval."
                        ))
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle(existingTask == nil
                             ? language.text("Neue Aufgabe", "New task")
                             : language.text("Bearbeiten", "Edit task"))
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("Abbrechen", "Cancel")) {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("Speichern", "Save"), action: save)
                        .disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }

    private func save() {
        let repeatDays = repeats ? repeatIntervalDays : nil
        let completionDate: Date?
        if repeatDays == nil {
            completionDate = nil
        } else if let savedCompletionDate = existingTask?.completedAt {
            completionDate = savedCompletionDate
        } else if existingTask?.completed == true {
            completionDate = Date()
        } else {
            completionDate = nil
        }

        let task = DisciplineTask(
            id: existingTask?.id ?? UUID(),
            title: title.trimmingCharacters(in: .whitespacesAndNewlines),
            details: details.trimmingCharacters(in: .whitespacesAndNewlines),
            duration: minutes * 60,
            completed: existingTask?.completed ?? false,
            scheduledTime: scheduledTime.trimmingCharacters(in: .whitespacesAndNewlines),
            repeatIntervalDays: repeatDays,
            completedAt: completionDate
        )
        onSave(task)
        dismiss()
    }
}

struct CameraCaptureView: UIViewControllerRepresentable {
    @Binding var isPresented: Bool
    let onCapture: (UIImage) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(isPresented: $isPresented, onCapture: onCapture)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.cameraCaptureMode = .photo
        picker.allowsEditing = false
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ controller: UIImagePickerController, context: Context) {}

    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        @Binding private var isPresented: Bool
        private let onCapture: (UIImage) -> Void

        init(isPresented: Binding<Bool>, onCapture: @escaping (UIImage) -> Void) {
            _isPresented = isPresented
            self.onCapture = onCapture
        }

        func imagePickerController(
            _ picker: UIImagePickerController,
            didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]
        ) {
            if let image = info[.originalImage] as? UIImage {
                onCapture(image)
            }
            isPresented = false
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            isPresented = false
        }
    }
}
